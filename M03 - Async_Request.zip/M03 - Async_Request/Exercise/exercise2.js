let show = function(data){
    let arr = JSON.parse(data);
    let dataj = document.getElementById("datajson");
    arr.forEach(datajson => {
        let out = "";
        out += `
        <tr>
            <td><a href="${datajson.website}" title="${datajson.company.name}">${datajson.id}</a></td>
            <td>${datajson.name}</td>
            <td>${datajson.username}</td>
            <td>${datajson.email}</td>
            <td>${datajson.address.city}</td>
        </tr>
        `;
        dataj.innerHTML += out;
    });
}

let load = function() {
    let link = "./data.json";
    let xhr;
    xhr = new XMLHttpRequest();
    try {
        xhr = new XMLHttpRequest();
        if (!xhr) return -1;

        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                show(xhr.responseText);
            }
        };
        xhr.open('GET', link);
        xhr.send();
    }
    catch(e) {
        console.log(e)
    }
}
load();